### Stichprobentechnik
![[Pasted image 20250227144156.png#invert]]

#### AQL
![[Pasted image 20250227144329.png#invert]]
![[Pasted image 20250227144823.png#invert]]

#### Stichprobenanweisung
**Einfach:** Stichprobeumfang(n), Annahmezahl(c) ve Rückwisezahl\[ret sayisi](d) belirlenmesi.
![[Pasted image 20250227145516.png#invert]]
**Doppel:** 
![[Pasted image 20250227145556.png#invert]]


![[Pasted image 20250227150429.png#invert]]

