![[Pasted image 20250227151315.png#invert]]
![[Pasted image 20250227151611.png#invert]]
Amina koymusun                                                     Dikkatli olmazsan amina koyar

![[Pasted image 20250227151746.png#invert]]

Fahigkeit boyle belirleniyo
![[Pasted image 20250227151848.png#invert]]

![[Pasted image 20250227152323.png#invert]]

![[Pasted image 20250227153540.png#invert]]
![[Pasted image 20250227160205.png#invert]]
![[Pasted image 20250227161007.png#invert]]
![[Pasted image 20250227161030.png#invert]]
