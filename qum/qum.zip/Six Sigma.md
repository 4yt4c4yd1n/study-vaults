![[Pasted image 20250227172155.png#invert]]
![[Pasted image 20250227172354.png#invert]]
![[Pasted image 20250227172757.png#invert]]
**DMAIC**

![[Pasted image 20250227172829.png#invert]]
![[Pasted image 20250227173357.png#invert]]
![[Pasted image 20250227173451.png#invert]]

### DFSS
![[Pasted image 20250227173732.png#invert]]
![[Pasted image 20250227173855.png#invert]]
![[Pasted image 20250227173954.png#invert]]

![[Pasted image 20250227174150.png#invert]]
![[Pasted image 20250227174220.png#invert]]
![[Pasted image 20250227174301.png#invert]]
![[Pasted image 20250227174331.png#invert]]
